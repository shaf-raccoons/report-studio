#!/usr/bin/env python3
"""Turn the artifact HTML into a deployable static folder."""
import urllib.request, re, os, sys

SRC = '/mnt/user-data/outputs/annual-report-studio.html'
OUT = '/home/claude/build'
UA  = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36"}
GOOGLE = ("https://fonts.googleapis.com/css2?"
 "family=Inter:wght@300..700"
 "&family=Instrument+Serif:ital@0;1"
 "&family=Newsreader:ital,opsz,wght@0,6..72,300..700;1,6..72,300..600"
 "&family=IBM+Plex+Mono:wght@400;500;600"
 "&family=Playfair+Display:wght@400..800"
 "&family=EB+Garamond:ital,wght@0,400..700;1,400"
 "&display=swap")

def fontface():
    css = urllib.request.urlopen(urllib.request.Request(GOOGLE, headers=UA), timeout=60).read().decode()
    blocks = re.findall(r"/\*\s*([a-z0-9\-\[\]]+)\s*\*/\s*@font-face\s*\{(.*?)\}", css, re.S)
    os.makedirs(OUT + '/fonts', exist_ok=True)
    rules, seen, dl = [], {}, 0
    for subset, body in blocks:
        if subset not in ('latin', 'latin-ext'):
            continue
        fam    = re.search(r"font-family:\s*'([^']+)'", body).group(1)
        style  = re.search(r"font-style:\s*([^;]+);", body).group(1).strip()
        weight = re.search(r"font-weight:\s*([^;]+);", body).group(1).strip()
        rng    = re.search(r"unicode-range:\s*([^;]+);", body).group(1).strip()
        src    = re.search(r"url\((https://[^)]+\.woff2)\)", body).group(1)
        if src not in seen:
            fn = '%s-%s-%s-%s.woff2' % (fam.lower().replace(' ', '-'), style, weight.replace(' ', '_'), subset)
            path = OUT + '/fonts/' + fn
            if not os.path.exists(path):
                open(path, 'wb').write(urllib.request.urlopen(urllib.request.Request(src, headers=UA), timeout=60).read())
                dl += 1
            seen[src] = fn
        rules.append("@font-face{font-family:'%s';font-style:%s;font-weight:%s;font-display:swap;"
                     "src:url('fonts/%s') format('woff2');unicode-range:%s}"
                     % (fam, style, weight, seen[src], rng))
    print('  fonts: %d files (%d newly downloaded)' % (len(seen), dl))
    return "\n".join(rules)

def patch(s, old, new, label):
    if old not in s:
        sys.exit('BUILD FAILED — could not find: ' + label)
    return s.replace(old, new, 1)

s = open(SRC).read()
print('source:', len(s), 'bytes')

# --- fonts ---
s = re.sub(r'<link rel="preconnect".*?rel="stylesheet">', '', s, count=1, flags=re.S)
s = patch(s, '<style>', '<style>\n/* FONTS — self-hosted. Page breaks are measured from real font metrics, so\n   they must not depend on a third-party CDN. Licences in fonts/OFL-*.txt */\n' + fontface() + '\n', 'style open')

# --- favicon ---
if 'rel="icon"' not in s:
    s = patch(s, '<title>Report Studio</title>',
      '''<title>Report Studio</title>\n<link rel="icon" href="data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 32 32'%3E%3Crect width='32' height='32' rx='7' fill='%2318181b'/%3E%3Cpath d='M11 8h9a1 1 0 0 1 1 1v14a1 1 0 0 1-1 1h-9z' fill='none' stroke='%23fff' stroke-width='2'/%3E%3Cpath d='M11 8v16' stroke='%23fff' stroke-width='2'/%3E%3C/svg%3E">''', 'title')

# --- storage: IndexedDB ---
s = patch(s, """async function sGet(key){
  try{ const r = await window.storage.get(key); return r && r.value ? JSON.parse(r.value) : null; }
  catch(e){ return null; }
}
async function sSet(key, val){
  try{ await window.storage.set(key, JSON.stringify(val)); storageOK = true; return true; }
  catch(e){ storageOK = false; return false; }
}
async function sDel(key){ try{ await window.storage.delete(key); }catch(e){} }

async function probeStorage(){
  try{ await window.storage.set('studio:probe', '1'); storageOK = true; }
  catch(e){ storageOK = false; }
}""", """/* ==========================================================================
   STORAGE — IndexedDB, so reports survive a refresh and images aren't capped
   by localStorage's few megabytes. Values are JSON strings, the same shape the
   rest of the app already expects.
   ========================================================================== */
const DB_NAME = 'report-studio', DB_VERSION = 1, STORE = 'kv';
let dbPromise = null;
function openDb(){
  if(dbPromise) return dbPromise;
  dbPromise = new Promise((resolve, reject) => {
    if(!('indexedDB' in window)) return reject(new Error('no indexedDB'));
    const req = indexedDB.open(DB_NAME, DB_VERSION);
    req.onupgradeneeded = () => {
      const db = req.result;
      if(!db.objectStoreNames.contains(STORE)) db.createObjectStore(STORE);
    };
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error || new Error('indexedDB blocked'));
    req.onblocked = () => reject(new Error('indexedDB blocked'));
  });
  return dbPromise;
}
function idb(mode, fn){
  return openDb().then(db => new Promise((resolve, reject) => {
    const tx = db.transaction(STORE, mode);
    const out = fn(tx.objectStore(STORE));
    tx.oncomplete = () => resolve(out ? out.result : undefined);
    tx.onerror = () => reject(tx.error);
    tx.onabort = () => reject(tx.error);
  }));
}
async function sGet(key){
  try{
    const v = await idb('readonly', st => st.get(key));
    return v == null ? null : JSON.parse(v);
  }catch(e){ return null; }
}
async function sSet(key, val){
  try{
    await idb('readwrite', st => st.put(JSON.stringify(val), key));
    storageOK = true;
    requestPersistence();
    return true;
  }catch(e){ storageOK = false; return false; }
}
async function sDel(key){ try{ await idb('readwrite', st => st.delete(key)); }catch(e){} }
async function sList(prefix){
  try{
    const keys = await idb('readonly', st => st.getAllKeys(IDBKeyRange.bound(prefix, prefix + '\\uffff')));
    return { keys: keys || [] };
  }catch(e){ return null; }
}
/* ask the browser not to evict the library when disk gets tight */
let persistAsked = false;
async function requestPersistence(){
  if(persistAsked) return;
  persistAsked = true;
  try{
    if(navigator.storage && navigator.storage.persist){
      if(!(await navigator.storage.persisted())) await navigator.storage.persist();
    }
  }catch(e){}
}
async function probeStorage(){
  try{
    await idb('readwrite', st => st.put('1', 'studio:probe'));
    storageOK = true;
  }catch(e){ storageOK = false; }
}""", 'storage layer')

s = patch(s, "    const r = await window.storage.list(prefix);", "    const r = await sList(prefix);", 'listKeys')
s = s.replace("  try{ window.storage.set('studio:ui', uiDark ? 'dark' : 'light'); }catch(e){}",
              "  sSet('studio:ui', uiDark ? 'dark' : 'light');")
s = patch(s, """  try{
    const r = await window.storage.get('studio:ui');
    if(r && r.value) uiDark = r.value === 'dark';
  }catch(e){}""", """  const savedUi = await sGet('studio:ui');
  if(savedUi === 'dark' || savedUi === 'light') uiDark = savedUi === 'dark';""", 'ui pref read')

# --- copy tweaks ---
s = patch(s, """<b style="font-weight:600">Reports won't persist here.</b>
     <span class="muted">This copy is running without storage, so anything you build lives in this tab only — use <b style="font-weight:500">Save file</b> to keep it.</span>""",
"""<b style="font-weight:600">This browser is blocking local storage.</b>
     <span class="muted">Private windows and some privacy settings disable it, so anything you build lives in this tab only — use <b style="font-weight:500">Save file</b> to keep it.</span>""", 'notice copy')
s = patch(s, """<span class="muted" style="font-size:.8125rem" id="libCount"></span></div>""",
"""<span class="muted" style="font-size:.8125rem" id="libCount"></span></div>
    <p class="muted" style="font-size:.8125rem;margin:-.375rem 0 .875rem">Saved in this browser. To hand a report to someone else, open it and use Save file.</p>""", 'library hint')

assert 'window.storage' not in s, 'window.storage still referenced'
assert 'fonts.googleapis' not in s, 'CDN still referenced'
open(OUT + '/index.html', 'w').write(s)
print('  index.html:', len(s), 'bytes')
print('BUILD OK')
